WEBSITE PT. MEGA KARUNIA BERKAH - PAKET REVISI

Isi paket:
- index.html: halaman utama website
- admin.html: editor lokal untuk pratinjau/pengaturan lokal
- logo-mkb.jpg: logo yang dikirim pengguna
- galeri-jamaah-*.jpg: foto galeri
- video-jamaah-*.mp4: video galeri

PENTING:
1. Upload semua isi folder ini ke direktori publik Netlify (jangan hanya index.html).
2. Pastikan index.html, logo-mkb.jpg, dan seluruh media berada pada direktori yang sama.
3. Halaman admin.html saat ini hanya menyimpan data pada browser yang digunakan; belum mengubah website publik dan bukan panel admin multi-perangkat. Untuk itu dibutuhkan CMS/backend serta autentikasi.
4. Nomor WhatsApp dan jadwal/harga/fasilitas perlu diverifikasi sebelum publikasi.
5. Fasilitas hotel pada paket utama ditulis: Hotel Mewah Bintang 4, Dekat Masjidil Haram.
