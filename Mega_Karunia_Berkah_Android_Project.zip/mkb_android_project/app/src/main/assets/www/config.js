// Isi dengan Project URL dan Publishable key Supabase Anda.
// Aman untuk frontend menggunakan publishable/anon key dengan RLS aktif.
// JANGAN masukkan service_role key atau secret key di sini.
window.MKB_SUPABASE_URL = "TEMPEL_PROJECT_URL_DI_SINI";
window.MKB_SUPABASE_ANON_KEY = "TEMPEL_PUBLISHABLE_KEY_DI_SINI";
