
-- MKB: Keamanan Supabase dan kebijakan akses
-- Jalankan satu kali di Supabase > SQL Editor.
-- Tidak membutuhkan service_role key di browser.

create table if not exists public.pengguna_mkb (
  id uuid primary key default gen_random_uuid(),
  nama text not null,
  email text,
  jabatan text not null,
  unit_kerja text,
  cabang text,
  wilayah text,
  atasan text,
  whatsapp text,
  status text not null default 'aktif' check (status in ('aktif','nonaktif')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.pengguna_mkb enable row level security;

create or replace function public.is_mkb_admin()
returns boolean
language sql
stable
security definer
set search_path = public, pg_temp
as $$
  select exists (
    select 1 from public.admin_mkb
    where user_id = auth.uid()
  );
$$;

revoke all on function public.is_mkb_admin() from public;
grant execute on function public.is_mkb_admin() to authenticated;

-- Bersihkan policy lama pada tabel MKB agar tidak ada policy permissive lama yang
-- tanpa sengaja membuka akses. Bagian ini hanya menyentuh tabel-tabel MKB berikut.
do $$
declare t text; p record;
begin
  foreach t in array array['admin_mkb','pengguna_mkb','paket_umroh','jadwal_umroh','galeri_mkb','hotel_mkb','pengaturan_mkb']
  loop
    for p in
      select policyname from pg_policies
      where schemaname = 'public' and tablename = t
    loop
      execute format('drop policy if exists %I on public.%I', p.policyname, t);
    end loop;
  end loop;
end $$;

-- Admin hanya boleh membaca baris admin miliknya sendiri.
drop policy if exists "mkb_admin_read_own" on public.admin_mkb;
create policy "mkb_admin_read_own"
on public.admin_mkb for select to authenticated
using (user_id = auth.uid());

-- Kebijakan tabel konten: publik hanya membaca konten aktif; admin dapat mengelola.
do $$
declare t text;
begin
  foreach t in array array['pengguna_mkb','paket_umroh','jadwal_umroh','galeri_mkb','hotel_mkb','pengaturan_mkb']
  loop
    execute format('drop policy if exists %I on public.%I', 'mkb_admin_all_'||t, t);
    execute format('create policy %I on public.%I for all to authenticated using (public.is_mkb_admin()) with check (public.is_mkb_admin())', 'mkb_admin_all_'||t, t);
  end loop;
end $$;

drop policy if exists "mkb_public_read_active_packages" on public.paket_umroh;
create policy "mkb_public_read_active_packages" on public.paket_umroh
for select to anon, authenticated using (status::text in ('aktif','active'));

drop policy if exists "mkb_public_read_available_schedules" on public.jadwal_umroh;
create policy "mkb_public_read_available_schedules" on public.jadwal_umroh
for select to anon, authenticated using (status::text in ('aktif','active','tersedia','available'));

drop policy if exists "mkb_public_read_active_gallery" on public.galeri_mkb;
create policy "mkb_public_read_active_gallery" on public.galeri_mkb
for select to anon, authenticated using (aktif = true);

drop policy if exists "mkb_public_read_active_hotels" on public.hotel_mkb;
create policy "mkb_public_read_active_hotels" on public.hotel_mkb
for select to anon, authenticated using (aktif = true);

drop policy if exists "mkb_public_read_safe_settings" on public.pengaturan_mkb;
create policy "mkb_public_read_safe_settings" on public.pengaturan_mkb
for select to anon, authenticated using (kunci in ('site_title','hero_text','hero_subtitle','whatsapp','banner_url','kontak','alamat'));

-- Pastikan hak SQL tersedia; RLS tetap membatasi baris yang dapat diakses.
grant select on public.admin_mkb to authenticated;
grant select, insert, update, delete on public.pengguna_mkb to authenticated;\ngrant select on public.paket_umroh, public.jadwal_umroh, public.galeri_mkb, public.hotel_mkb, public.pengaturan_mkb to anon, authenticated;
grant insert, update, delete on public.paket_umroh, public.jadwal_umroh, public.galeri_mkb, public.hotel_mkb, public.pengaturan_mkb to authenticated;

-- Bucket media publik: pengunjung bisa melihat media, hanya admin yang bisa mengunggah/mengubah/menghapus.
insert into storage.buckets (id, name, public)
values ('mkb-media', 'mkb-media', true)
on conflict (id) do update set public = true;

drop policy if exists "mkb_public_read_media" on storage.objects;
create policy "mkb_public_read_media" on storage.objects
for select to anon, authenticated using (bucket_id = 'mkb-media');

drop policy if exists "mkb_admin_upload_media" on storage.objects;
create policy "mkb_admin_upload_media" on storage.objects
for insert to authenticated with check (bucket_id = 'mkb-media' and public.is_mkb_admin());

drop policy if exists "mkb_admin_update_media" on storage.objects;
create policy "mkb_admin_update_media" on storage.objects
for update to authenticated using (bucket_id = 'mkb-media' and public.is_mkb_admin())
with check (bucket_id = 'mkb-media' and public.is_mkb_admin());

drop policy if exists "mkb_admin_delete_media" on storage.objects;
create policy "mkb_admin_delete_media" on storage.objects
for delete to authenticated using (bucket_id = 'mkb-media' and public.is_mkb_admin());

-- CATATAN: jangan menaruh service_role/secret key di file JavaScript website.
