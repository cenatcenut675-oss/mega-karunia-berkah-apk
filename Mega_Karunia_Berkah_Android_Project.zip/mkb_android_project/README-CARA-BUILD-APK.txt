MEGA KARUNIA BERKAH — PROYEK ANDROID

Isi proyek ini membungkus website dari ZIP Mega Karunia Berkah Website Menu Fixed ke aplikasi Android WebView. File website, logo-mkb.jpg, galeri, video, index.html, admin.html dan config.js disertakan apa adanya.

CARA MEMBUAT APK (perlu komputer/laptop):
1. Pasang Android Studio dari situs resmi Android Developer.
2. Ekstrak ZIP proyek ini.
3. Buka Android Studio > Open > pilih folder MegaKaruniaBerkah (folder ini).
4. Tunggu Gradle Sync selesai dan izinkan Android Studio memasang komponen SDK yang diminta.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Setelah selesai, klik Locate. APK debug biasanya ada di app/build/outputs/apk/debug/app-debug.apk.
7. Kirim APK itu ke HP Android dan buka untuk memasang. Jika diminta, izinkan pemasangan aplikasi dari sumber tersebut.

CATATAN:
- Ini adalah proyek sumber Android, bukan file APK siap pasang. Lingkungan pembuatan ini tidak memiliki Android SDK/Gradle yang dibutuhkan untuk menghasilkan APK secara langsung.
- Aplikasi membuka salinan website secara lokal; perubahan yang hanya dipasang di Netlify tidak otomatis mengubah salinan lokal dalam APK.
- Pengaturan Supabase/fitur admin tetap mengikuti file config.js dan konfigurasi website yang disertakan. Jangan menaruh kunci rahasia/service-role di aplikasi.
